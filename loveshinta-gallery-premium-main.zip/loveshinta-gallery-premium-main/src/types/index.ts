export type ContentType = 'image' | 'video';

export interface Content {
  id: string;
  title: string;
  description: string;
  url: string;
  type: ContentType;
  price: number;
  createdAt: string;
}

export interface EWalletInfo {
  name: string;
  number: string;
}

export interface PaymentRequest {
  id: string;
  content_id: string;
  user_id: string;
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
  payment_method: string;
  payment_proof?: string | null;
  created_at: string;
  content?: Content;
}
