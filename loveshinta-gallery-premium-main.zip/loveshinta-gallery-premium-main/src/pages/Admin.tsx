
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Content } from '../types';
import { getContents, addContent, updateContent, deleteContent } from '../utils/mockData';
import Header from '../components/Header';
import ContentForm from '../components/admin/ContentForm';
import ContentList from '../components/admin/ContentList';
import PaymentSettings from '../components/admin/PaymentSettings';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2 } from 'lucide-react';

interface PaymentRequest {
  id: string;
  content_id: string;
  user_id: string;
  amount: number;
  status: string;
  payment_method: string;
  payment_proof: string | null;
  created_at: string;
  content_title?: string;
  user_email?: string;
}

const Admin = () => {
  const [isAdmin, setIsAdmin] = useState(false);
  const [contents, setContents] = useState<Content[]>([]);
  const [isAddingContent, setIsAddingContent] = useState(false);
  const [editingContent, setEditingContent] = useState<Content | null>(null);
  const [activeTab, setActiveTab] = useState('content');
  const [isLoading, setIsLoading] = useState(false);
  const [paymentRequests, setPaymentRequests] = useState<PaymentRequest[]>([]);
  const [isLoadingRequests, setIsLoadingRequests] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    // Check if user is admin
    const checkAdmin = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        
        if (!user) {
          toast({
            title: "Access denied",
            description: "You need to login first",
            variant: "destructive",
          });
          navigate('/');
          return;
        }
        
        // Check if the user is the hardcoded admin
        if (user.email === 'sfajriaty410@gmail.com') {
          setIsAdmin(true);
          localStorage.setItem('isAdmin', 'true');
          loadContents();
          return;
        }
        
        // If not the hardcoded admin, check the user_roles table
        const { data: roles, error } = await supabase
          .from('user_roles')
          .select('*')
          .eq('user_id', user.id)
          .eq('role', 'admin');
        
        if (error) {
          console.error('Error checking admin status:', error);
          toast({
            title: "Error checking permissions",
            description: "There was a problem checking your admin status",
            variant: "destructive",
          });
          navigate('/');
          return;
        }
        
        if (roles && roles.length > 0) {
          setIsAdmin(true);
          localStorage.setItem('isAdmin', 'true');
          loadContents();
          return;
        }
        
        // For backward compatibility, also check localStorage
        const adminStatus = localStorage.getItem('isAdmin');
        if (adminStatus === 'true') {
          // Migrate the admin status to the database
          try {
            await supabase
              .from('user_roles')
              .upsert([{ user_id: user.id, role: 'admin' }]);
              
            setIsAdmin(true);
            loadContents();
            return;
          } catch (error) {
            console.error('Error migrating admin status:', error);
          }
        }
        
        toast({
          title: "Access denied",
          description: "You don't have permission to view this page",
          variant: "destructive",
        });
        navigate('/');
      } catch (error) {
        console.error('Error checking admin status:', error);
        toast({
          title: "Error checking permissions",
          description: "There was a problem checking your admin status",
          variant: "destructive",
        });
        navigate('/');
      }
    };
    
    checkAdmin();
  }, [navigate, toast]);

  useEffect(() => {
    if (isAdmin && activeTab === 'payment-requests') {
      loadPaymentRequests();
    }
  }, [isAdmin, activeTab]);

  const loadContents = async () => {
    setIsLoading(true);
    try {
      const data = await getContents();
      setContents(data);
    } catch (error) {
      console.error('Error loading contents:', error);
      toast({
        title: "Error loading content",
        description: "There was a problem loading the content",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const loadPaymentRequests = async () => {
    setIsLoadingRequests(true);
    try {
      // Get payment requests with content title
      const { data: requests, error } = await supabase
        .from('payment_requests')
        .select(`
          *,
          gallery_content:content_id (title)
        `)
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      
      // Format data
      const formattedRequests = requests.map((req: any) => ({
        ...req,
        content_title: req.gallery_content?.title || 'Unknown'
      }));
      
      setPaymentRequests(formattedRequests);
    } catch (error) {
      console.error('Error loading payment requests:', error);
      toast({
        title: "Error loading payment requests",
        description: "There was a problem loading the payment requests",
        variant: "destructive",
      });
    } finally {
      setIsLoadingRequests(false);
    }
  };

  const handleApprovePayment = async (request: PaymentRequest) => {
    try {
      // First update the payment request status
      const { error: updateError } = await supabase
        .from('payment_requests')
        .update({ status: 'approved' })
        .eq('id', request.id);
        
      if (updateError) throw updateError;
      
      // Then create a purchase record
      const { error: purchaseError } = await supabase
        .from('purchases')
        .insert({
          content_id: request.content_id,
          user_id: request.user_id,
          payment_request_id: request.id
        });
        
      if (purchaseError) throw purchaseError;
      
      toast({
        title: "Payment approved",
        description: "User now has access to the content",
      });
      
      // Refresh the list
      loadPaymentRequests();
    } catch (error: any) {
      console.error('Error approving payment:', error);
      toast({
        title: "Error approving payment",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleRejectPayment = async (requestId: string) => {
    try {
      const { error } = await supabase
        .from('payment_requests')
        .update({ status: 'rejected' })
        .eq('id', requestId);
        
      if (error) throw error;
      
      toast({
        title: "Payment rejected",
        description: "Payment request has been rejected",
      });
      
      // Refresh the list
      loadPaymentRequests();
    } catch (error: any) {
      console.error('Error rejecting payment:', error);
      toast({
        title: "Error rejecting payment",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    localStorage.removeItem('isAdmin');
    setIsAdmin(false);
    navigate('/');
  };

  const handleAddContent = async (data: Omit<Content, 'id' | 'createdAt'>) => {
    setIsLoading(true);
    try {
      const newContent = await addContent(data);
      if (newContent) {
        setIsAddingContent(false);
        await loadContents();
        toast({
          title: "Content added",
          description: "New content has been added to the gallery",
        });
      } else {
        toast({
          title: "Error adding content",
          description: "There was a problem adding the content",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Error adding content:', error);
      toast({
        title: "Error adding content",
        description: "There was a problem adding the content",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateContent = async (data: Omit<Content, 'id' | 'createdAt'>) => {
    if (editingContent) {
      setIsLoading(true);
      try {
        const updated = await updateContent(editingContent.id, data);
        if (updated) {
          setEditingContent(null);
          await loadContents();
          toast({
            title: "Content updated",
            description: "The content has been updated",
          });
        } else {
          toast({
            title: "Error updating content",
            description: "There was a problem updating the content",
            variant: "destructive",
          });
        }
      } catch (error) {
        console.error('Error updating content:', error);
        toast({
          title: "Error updating content",
          description: "There was a problem updating the content",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    }
  };

  const handleDeleteContent = async (id: string) => {
    setIsLoading(true);
    try {
      const success = await deleteContent(id);
      if (success) {
        await loadContents();
        toast({
          title: "Content deleted",
          description: "The content has been removed",
        });
      } else {
        toast({
          title: "Error deleting content",
          description: "There was a problem deleting the content",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Error deleting content:', error);
      toast({
        title: "Error deleting content",
        description: "There was a problem deleting the content",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isAdmin && activeTab === 'payment-requests') {
      loadPaymentRequests();
    }
  }, [isAdmin, activeTab]);

  if (!isAdmin) {
    return <div className="p-8 text-center">Checking permissions...</div>;
  }

  if (isLoading && !isAddingContent && !editingContent) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow">
          <div className="container mx-auto px-4 py-8">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-3xl font-bold">Admin Dashboard</h1>
              <button
                onClick={handleLogout}
                className="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded-md"
              >
                Logout
              </button>
            </div>
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-12 w-12 animate-spin text-shinta-pink" />
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold">Admin Dashboard</h1>
            <button
              onClick={handleLogout}
              className="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded-md"
            >
              Logout
            </button>
          </div>
          
          <div className="admin-panel p-6">
            <Tabs defaultValue="content" value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="mb-6">
                <TabsTrigger value="content">Content Management</TabsTrigger>
                <TabsTrigger value="payments">Payment Settings</TabsTrigger>
                <TabsTrigger value="payment-requests">Payment Requests</TabsTrigger>
              </TabsList>
              
              <TabsContent value="content">
                {isAddingContent ? (
                  <div className="bg-white rounded-lg p-6 mb-6">
                    <h2 className="text-xl font-bold mb-4">Add New Content</h2>
                    <ContentForm 
                      onSave={handleAddContent} 
                      onCancel={() => setIsAddingContent(false)}
                    />
                  </div>
                ) : editingContent ? (
                  <div className="bg-white rounded-lg p-6 mb-6">
                    <h2 className="text-xl font-bold mb-4">Edit Content</h2>
                    <ContentForm 
                      initialData={editingContent}
                      onSave={handleUpdateContent} 
                      onCancel={() => setEditingContent(null)}
                    />
                  </div>
                ) : (
                  <div className="mb-6">
                    <button
                      onClick={() => setIsAddingContent(true)}
                      className="px-4 py-2 bg-shinta-pink text-white rounded-md hover:bg-shinta-red"
                    >
                      Add New Content
                    </button>
                  </div>
                )}

                {!(isAddingContent || editingContent) && (
                  <div className="bg-white rounded-lg p-6">
                    <h2 className="text-xl font-bold mb-4">Content Library</h2>
                    <ContentList 
                      contents={contents} 
                      onEdit={setEditingContent} 
                      onDelete={handleDeleteContent}
                    />
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="payments">
                <PaymentSettings />
              </TabsContent>
              
              <TabsContent value="payment-requests">
                <div className="bg-white rounded-lg p-6">
                  <h2 className="text-xl font-bold mb-4">Payment Requests</h2>
                  
                  {isLoadingRequests ? (
                    <div className="flex justify-center py-8">
                      <Loader2 className="h-8 w-8 animate-spin text-shinta-pink" />
                    </div>
                  ) : paymentRequests.length === 0 ? (
                    <p className="text-gray-500 text-center py-8">No payment requests found</p>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Content
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              User ID
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Amount
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Method
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Status
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Date
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Actions
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {paymentRequests.map((request) => (
                            <tr key={request.id}>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm font-medium text-gray-900">{request.content_title}</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-gray-500">{request.user_id}</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-gray-900">Rp {request.amount.toLocaleString('id-ID')}</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-gray-500">{request.payment_method}</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                  ${request.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                                    request.status === 'approved' ? 'bg-green-100 text-green-800' : 
                                    'bg-red-100 text-red-800'}`}
                                >
                                  {request.status}
                                </span>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-gray-500">
                                  {new Date(request.created_at).toLocaleDateString()}
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                {request.status === 'pending' && (
                                  <div className="flex space-x-2">
                                    <button
                                      onClick={() => handleApprovePayment(request)}
                                      className="text-green-600 hover:text-green-900"
                                    >
                                      Approve
                                    </button>
                                    <button
                                      onClick={() => handleRejectPayment(request.id)}
                                      className="text-red-600 hover:text-red-900"
                                    >
                                      Reject
                                    </button>
                                  </div>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Admin;
