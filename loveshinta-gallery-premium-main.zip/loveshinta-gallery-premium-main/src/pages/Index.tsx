
import React from 'react';
import Header from '../components/Header';
import Gallery from '../components/Gallery';
import { useAuth } from '@/context/AuthContext';

const Index = () => {
  const { user } = useAuth();
  
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-white to-shinta-softPink">
      <Header />
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-12">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-shinta-red to-shinta-pink bg-clip-text text-transparent">
              LOVABLE SHINTA 18+
            </h1>
            <p className="text-xl text-gray-700 leading-relaxed">
              Exclusive premium content available with one-time purchases
            </p>
            {user ? (
              <p className="mt-4 text-lg text-shinta-pink">
                Welcome back, {user.email?.split('@')[0]}! Browse our exclusive content below.
              </p>
            ) : (
              <p className="mt-4 text-lg text-gray-600">
                Click on any content to register or login. New users get special access!
              </p>
            )}
            <div className="mt-8 w-24 h-1 bg-gradient-to-r from-shinta-red to-shinta-pink rounded-full mx-auto"></div>
          </div>
          
          <Gallery />
        </div>
      </main>
      <footer className="bg-gradient-to-r from-gray-800 to-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center md:text-left">
              <h3 className="text-2xl font-bold mb-4 bg-gradient-to-r from-shinta-pink to-shinta-red bg-clip-text text-transparent">
                LOVABLE SHINTA
              </h3>
              <p className="text-gray-300">Premium adult content for discerning viewers.</p>
            </div>
            
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4 text-white">Quick Links</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-300 hover:text-shinta-pink transition-colors">Home</a></li>
                <li><a href="#" className="text-gray-300 hover:text-shinta-pink transition-colors">Premium Content</a></li>
                <li><a href="#" className="text-gray-300 hover:text-shinta-pink transition-colors">Contact</a></li>
              </ul>
            </div>
            
            <div className="text-center md:text-right">
              <h3 className="text-xl font-semibold mb-4 text-white">Follow Us</h3>
              <div className="flex justify-center md:justify-end space-x-4">
                <a href="#" className="text-gray-300 hover:text-shinta-pink transition-colors">
                  <span className="text-2xl">📱</span>
                </a>
                <a href="#" className="text-gray-300 hover:text-shinta-pink transition-colors">
                  <span className="text-2xl">📸</span>
                </a>
                <a href="#" className="text-gray-300 hover:text-shinta-pink transition-colors">
                  <span className="text-2xl">💬</span>
                </a>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-8 pt-8 text-center">
            <p>&copy; {new Date().getFullYear()} LOVABLE SHINTA 18+. All rights reserved.</p>
            <p className="text-sm text-gray-400 mt-2">
              This site contains adult content and is intended for adults only.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
