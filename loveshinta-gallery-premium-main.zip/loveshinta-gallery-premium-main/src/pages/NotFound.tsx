
import React from 'react';
import { Link } from 'react-router-dom';

const NotFound = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-r from-shinta-pink/20 to-shinta-red/20 p-4">
      <div className="text-center max-w-md">
        <h1 className="text-6xl font-bold mb-4 text-shinta-pink">404</h1>
        <h2 className="text-2xl font-bold mb-4">Page Not Found</h2>
        <p className="mb-6 text-gray-600">
          The page you are looking for doesn't exist or has been moved.
        </p>
        <Link 
          to="/" 
          className="inline-block px-6 py-3 bg-gradient-to-r from-shinta-pink to-shinta-red text-white rounded-md hover:opacity-90"
        >
          Return to Home
        </Link>
      </div>
    </div>
  );
};

export default NotFound;
