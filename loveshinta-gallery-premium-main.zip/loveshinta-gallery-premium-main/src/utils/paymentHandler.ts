
import { supabase } from '@/integrations/supabase/client';
import { EWalletInfo } from '../types';

// Check if a user has purchased content
export const hasPurchased = async (contentId: string): Promise<boolean> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return false;
    
    const { data, error } = await supabase
      .from('purchases')
      .select('id')
      .eq('content_id', contentId)
      .eq('user_id', user.id)
      .maybeSingle();
    
    if (error) {
      console.error('Error checking purchase:', error);
      return false;
    }
    
    return !!data;
  } catch (error) {
    console.error('Error in hasPurchased:', error);
    return false;
  }
};

// Record a purchase in Supabase
export const recordPurchase = async (contentId: string): Promise<boolean> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return false;
    
    const { error } = await supabase
      .from('purchases')
      .insert({
        content_id: contentId,
        user_id: user.id
      });
    
    return !error;
  } catch (error) {
    console.error('Error in recordPurchase:', error);
    return false;
  }
};

// Get payment settings
export const getPaymentUrls = () => {
  const savedUrls = localStorage.getItem('paymentUrls');
  if (savedUrls) {
    return JSON.parse(savedUrls);
  }
  
  // Default values
  const defaultUrls = {
    ewallet: '',
    qris: ''
  };
  
  localStorage.setItem('paymentUrls', JSON.stringify(defaultUrls));
  return defaultUrls;
};

export const setPaymentUrls = (urls: { ewallet: string, qris: string }) => {
  localStorage.setItem('paymentUrls', JSON.stringify(urls));
};

// E-wallet info handler
export const getEWalletInfo = (): EWalletInfo => {
  const savedInfo = localStorage.getItem('ewalletInfo');
  if (savedInfo) {
    return JSON.parse(savedInfo);
  }
  
  // Default values
  const defaultInfo: EWalletInfo = {
    name: 'Shinta',
    number: '081234567890'
  };
  
  localStorage.setItem('ewalletInfo', JSON.stringify(defaultInfo));
  return defaultInfo;
};

export const setEWalletInfo = (info: EWalletInfo) => {
  localStorage.setItem('ewalletInfo', JSON.stringify(info));
};

// Create a payment request
export const createPaymentRequest = async (contentId: string, price: number, paymentMethod: string) => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { success: false, error: 'User not authenticated' };
    
    const { data, error } = await supabase
      .from('payment_requests')
      .insert({
        content_id: contentId,
        user_id: user.id,
        amount: price,
        payment_method: paymentMethod
      })
      .select();
    
    if (error) return { success: false, error: error.message };
    
    return { success: true, data };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
};

// Check payment request status
export const checkPaymentRequestStatus = async (contentId: string) => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { status: null };
    
    const { data, error } = await supabase
      .from('payment_requests')
      .select('status')
      .eq('content_id', contentId)
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(1);
    
    if (error || !data || data.length === 0) {
      return { status: null };
    }
    
    return { status: data[0].status };
  } catch (error) {
    console.error('Error checking payment status:', error);
    return { status: null };
  }
};
