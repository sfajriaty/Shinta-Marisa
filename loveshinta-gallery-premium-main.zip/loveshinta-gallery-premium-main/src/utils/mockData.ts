import { Content } from '../types';
import { supabase } from '@/integrations/supabase/client';

// Function to get content from Supabase
export const getContents = async (): Promise<Content[]> => {
  const { data, error } = await supabase
    .from('gallery_content')
    .select('*')
    .order('created_at', { ascending: false });
  
  if (error) {
    console.error('Error fetching contents:', error);
    return [];
  }
  
  // Transform the Supabase data to match our Content type
  return data.map(item => ({
    id: item.id,
    title: item.title,
    description: item.description || '',
    url: item.url,
    type: item.type as 'image' | 'video',
    price: item.price,
    createdAt: item.created_at,
  }));
};

// Add new content to Supabase
export const addContent = async (content: Omit<Content, 'id' | 'createdAt'>): Promise<Content | null> => {
  const { data, error } = await supabase
    .from('gallery_content')
    .insert({
      title: content.title,
      description: content.description,
      url: content.url,
      type: content.type,
      price: content.price,
    })
    .select()
    .single();
  
  if (error) {
    console.error('Error adding content:', error);
    return null;
  }
  
  // Transform the returned data to match our Content type
  return {
    id: data.id,
    title: data.title,
    description: data.description || '',
    url: data.url,
    type: data.type as 'image' | 'video',
    price: data.price,
    createdAt: data.created_at,
  };
};

// Update existing content in Supabase
export const updateContent = async (id: string, updates: Partial<Content>): Promise<Content | null> => {
  // Remove id and createdAt from updates if they exist
  const { id: _, createdAt: __, ...validUpdates } = updates as any;
  
  const { data, error } = await supabase
    .from('gallery_content')
    .update(validUpdates)
    .eq('id', id)
    .select()
    .single();
  
  if (error) {
    console.error('Error updating content:', error);
    return null;
  }
  
  // Transform the returned data to match our Content type
  return {
    id: data.id,
    title: data.title,
    description: data.description || '',
    url: data.url,
    type: data.type as 'image' | 'video',
    price: data.price,
    createdAt: data.created_at,
  };
};

// Delete content from Supabase
export const deleteContent = async (id: string): Promise<boolean> => {
  const { error } = await supabase
    .from('gallery_content')
    .delete()
    .eq('id', id);
  
  if (error) {
    console.error('Error deleting content:', error);
    return false;
  }
  
  return true;
};

// Reset all content (for development purposes only)
export const resetAllContent = async (): Promise<void> => {
  const { error } = await supabase
    .from('gallery_content')
    .delete()
    .neq('id', '00000000-0000-0000-0000-000000000000'); // Delete all content
  
  if (error) {
    console.error('Error resetting content:', error);
  }
};

// Functions for purchases
// Check if a user has purchased content
export const hasPurchased = async (contentId: string): Promise<boolean> => {
  // For now, let's assume all content is purchased for simplicity
  return true;
  
  // In a real implementation with auth, you would do:
  /*
  const { data, error } = await supabase
    .from('purchases')
    .select('id')
    .eq('content_id', contentId)
    .eq('user_id', supabase.auth.user()?.id)
    .single();
  
  return !error && !!data;
  */
};

// Record a purchase in Supabase
export const recordPurchase = async (contentId: string): Promise<boolean> => {
  // For now, just return true for simplicity
  return true;
  
  // In a real implementation with auth, you would do:
  /*
  const { error } = await supabase
    .from('purchases')
    .insert({
      content_id: contentId,
      user_id: supabase.auth.user()?.id
    });
  
  return !error;
  */
};
