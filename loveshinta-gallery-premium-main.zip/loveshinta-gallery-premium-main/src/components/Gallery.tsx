
import React, { useEffect, useState } from 'react';
import ContentCard from './ContentCard';
import { Content } from '../types';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';

const Gallery = () => {
  const [contents, setContents] = useState<Content[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    // Get content from Supabase
    const loadContents = async () => {
      setIsLoading(true);
      try {
        const { data, error } = await supabase
          .from('gallery_content')
          .select('*')
          .order('created_at', { ascending: false });
        
        if (error) {
          console.error('Error fetching gallery content:', error);
          toast({
            title: 'Error loading content',
            description: 'There was an error loading the gallery content.',
            variant: 'destructive',
          });
          setContents([]);
        } else {
          // Transform the Supabase data to match our Content type
          const transformedData = data.map(item => ({
            id: item.id,
            title: item.title,
            description: item.description || '',
            url: item.url,
            type: item.type as 'image' | 'video',
            price: item.price,
            createdAt: item.created_at,
          }));
          
          setContents(transformedData);
        }
      } catch (error) {
        console.error('Unexpected error:', error);
        toast({
          title: 'Error loading content',
          description: 'There was an unexpected error loading the gallery content.',
          variant: 'destructive',
        });
        setContents([]);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadContents();
    
    // Set up a subscription to listen for changes to the gallery_content table
    const channel = supabase
      .channel('schema-db-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'gallery_content',
        },
        (payload) => {
          console.log('Gallery content changed:', payload);
          loadContents();
        }
      )
      .subscribe();
    
    return () => {
      supabase.removeChannel(channel);
    };
  }, [toast]);

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-12 w-12 animate-spin text-shinta-pink" />
        </div>
      </div>
    );
  }

  if (contents.length === 0) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <div className="bg-gradient-to-r from-shinta-softPink to-pink-50 p-8 rounded-xl shadow-md">
          <p className="text-xl text-gray-600">Belum ada konten. Silakan tambahkan konten di panel admin.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h2 className="text-3xl font-bold mb-8 text-center bg-gradient-to-r from-shinta-red to-shinta-pink bg-clip-text text-transparent">Premium Content Gallery</h2>
      <div className="gallery-grid gap-6">
        {contents.map((content) => (
          <ContentCard key={content.id} content={content} />
        ))}
      </div>
    </div>
  );
};

export default Gallery;
