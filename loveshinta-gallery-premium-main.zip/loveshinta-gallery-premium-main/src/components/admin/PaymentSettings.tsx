
import React, { useState, useEffect } from 'react';
import { getPaymentUrls, setPaymentUrls } from '../../utils/paymentHandler';
import { useToast } from '@/hooks/use-toast';

const PaymentSettings: React.FC = () => {
  const [ewalletName, setEwalletName] = useState('');
  const [ewalletNumber, setEwalletNumber] = useState('');
  const [qrisUrl, setQrisUrl] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    const urls = getPaymentUrls();
    
    // Parse ewallet information if available
    if (urls.ewallet) {
      try {
        const ewalletInfo = JSON.parse(urls.ewallet);
        setEwalletName(ewalletInfo.name || '');
        setEwalletNumber(ewalletInfo.number || '');
      } catch (e) {
        // Handle legacy format
        setEwalletName('');
        setEwalletNumber('');
      }
    }
    
    setQrisUrl(urls.qris || '');
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Store ewallet information as JSON string
    const ewalletInfo = JSON.stringify({
      name: ewalletName,
      number: ewalletNumber
    });
    
    setPaymentUrls({
      ewallet: ewalletInfo,
      qris: qrisUrl
    });
    
    toast({
      title: "Pengaturan diperbarui",
      description: "Informasi pembayaran Anda telah disimpan",
    });
  };

  return (
    <div className="bg-white rounded-lg p-6">
      <h2 className="text-xl font-bold mb-4">Pengaturan Pembayaran</h2>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block font-medium mb-1">Informasi E-Wallet</label>
          
          <div className="space-y-2">
            <input
              type="text"
              value={ewalletName}
              onChange={(e) => setEwalletName(e.target.value)}
              className="w-full px-3 py-2 border rounded-md"
              placeholder="Nama Penerima"
            />
            
            <input
              type="text"
              value={ewalletNumber}
              onChange={(e) => setEwalletNumber(e.target.value)}
              className="w-full px-3 py-2 border rounded-md"
              placeholder="Nomor E-Wallet"
            />
          </div>
          
          <p className="text-xs text-gray-500 mt-1">
            Masukkan nama dan nomor e-wallet Anda
          </p>
        </div>
        
        <div>
          <label className="block font-medium mb-1">URL Pembayaran QRIS</label>
          <input
            type="url"
            value={qrisUrl}
            onChange={(e) => setQrisUrl(e.target.value)}
            className="w-full px-3 py-2 border rounded-md"
            placeholder="https://your-payment-url.com/qris"
          />
          <p className="text-xs text-gray-500 mt-1">
            Masukkan URL tempat pelanggan dapat membayar menggunakan QRIS
          </p>
        </div>
        
        <div className="pt-4">
          <button
            type="submit"
            className="px-4 py-2 bg-shinta-pink text-white rounded-md hover:bg-shinta-red"
          >
            Simpan Pengaturan
          </button>
        </div>
      </form>
    </div>
  );
};

export default PaymentSettings;
