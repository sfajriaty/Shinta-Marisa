
import React from 'react';
import { Content } from '../../types';
import { useToast } from '@/hooks/use-toast';

interface ContentListProps {
  contents: Content[];
  onEdit: (content: Content) => void;
  onDelete: (id: string) => void;
}

const ContentList: React.FC<ContentListProps> = ({ contents, onEdit, onDelete }) => {
  const { toast } = useToast();
  
  const confirmDelete = (content: Content) => {
    if (window.confirm(`Are you sure you want to delete "${content.title}"?`)) {
      onDelete(content.id);
      toast({
        title: "Content deleted",
        description: "The content has been removed from the gallery",
      });
    }
  };
  
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  if (contents.length === 0) {
    return <p className="text-center py-8 text-gray-500">No content available. Add some content to get started!</p>;
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="bg-gray-50 border-b">
            <th className="px-4 py-2 text-left">Title</th>
            <th className="px-4 py-2 text-left hidden md:table-cell">Type</th>
            <th className="px-4 py-2 text-left hidden md:table-cell">Price</th>
            <th className="px-4 py-2 text-left hidden md:table-cell">Created</th>
            <th className="px-4 py-2 text-right">Actions</th>
          </tr>
        </thead>
        <tbody>
          {contents.map((content) => (
            <tr key={content.id} className="border-b hover:bg-gray-50">
              <td className="px-4 py-3 truncate max-w-[200px]">{content.title}</td>
              <td className="px-4 py-3 hidden md:table-cell">
                <span className={`px-2 py-1 rounded-full text-xs ${
                  content.type === 'image' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'
                }`}>
                  {content.type}
                </span>
              </td>
              <td className="px-4 py-3 hidden md:table-cell">${content.price.toFixed(2)}</td>
              <td className="px-4 py-3 hidden md:table-cell">{formatDate(content.createdAt)}</td>
              <td className="px-4 py-3 text-right">
                <button 
                  onClick={() => onEdit(content)}
                  className="text-blue-600 hover:text-blue-800 mr-3"
                >
                  Edit
                </button>
                <button 
                  onClick={() => confirmDelete(content)}
                  className="text-red-600 hover:text-red-800"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ContentList;
