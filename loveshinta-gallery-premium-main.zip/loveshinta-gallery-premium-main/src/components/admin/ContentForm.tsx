
import React, { useState } from 'react';
import { Content, ContentType } from '../../types';
import { useToast } from '@/hooks/use-toast';

interface ContentFormProps {
  initialData?: Content;
  onSave: (data: Omit<Content, 'id' | 'createdAt'>) => void;
  onCancel: () => void;
}

const ContentForm: React.FC<ContentFormProps> = ({ initialData, onSave, onCancel }) => {
  const [title, setTitle] = useState(initialData?.title || '');
  const [description, setDescription] = useState(initialData?.description || '');
  const [url, setUrl] = useState(initialData?.url || '');
  const [type, setType] = useState<ContentType>(initialData?.type || 'image');
  const [price, setPrice] = useState(initialData?.price || 5.99);
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim() || !description.trim() || !url.trim()) {
      toast({
        title: "Missing fields",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }
    
    onSave({
      title,
      description,
      url,
      type,
      price,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block font-medium mb-1">Title</label>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full px-3 py-2 border rounded-md"
          required
        />
      </div>
      
      <div>
        <label className="block font-medium mb-1">Description</label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="w-full px-3 py-2 border rounded-md"
          rows={3}
          required
        />
      </div>
      
      <div>
        <label className="block font-medium mb-1">URL</label>
        <input
          type="text"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          className="w-full px-3 py-2 border rounded-md"
          placeholder="URL to image or video"
          required
        />
      </div>
      
      <div>
        <label className="block font-medium mb-1">Type</label>
        <select
          value={type}
          onChange={(e) => setType(e.target.value as ContentType)}
          className="w-full px-3 py-2 border rounded-md"
        >
          <option value="image">Image</option>
          <option value="video">Video</option>
        </select>
      </div>
      
      <div>
        <label className="block font-medium mb-1">Price ($)</label>
        <input
          type="number"
          value={price}
          onChange={(e) => setPrice(Number(e.target.value))}
          step="0.01"
          min="0.99"
          className="w-full px-3 py-2 border rounded-md"
          required
        />
      </div>
      
      <div className="flex justify-end space-x-2 pt-4">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 border rounded-md hover:bg-gray-100"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="px-4 py-2 bg-shinta-pink text-white rounded-md hover:bg-shinta-red"
        >
          Save
        </button>
      </div>
    </form>
  );
};

export default ContentForm;
