
// Re-export from the correct location
import { useToast, toast } from "@/hooks/use-toast"

export { useToast, toast }
