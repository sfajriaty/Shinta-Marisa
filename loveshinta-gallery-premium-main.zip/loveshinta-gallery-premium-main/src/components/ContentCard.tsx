
import React, { useState, useEffect } from 'react';
import { Content } from '../types';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { IndianRupee, QrCode } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';

interface ContentCardProps {
  content: Content;
}

const ContentCard: React.FC<ContentCardProps> = ({ content }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isPurchasing, setIsPurchasing] = useState(false);
  const [showTransferOptions, setShowTransferOptions] = useState(false);
  const [hasAccess, setHasAccess] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLogin, setIsLogin] = useState(true);
  const [paymentRequestStatus, setPaymentRequestStatus] = useState<string | null>(null);
  const { toast } = useToast();
  const { user } = useAuth();

  // Check if user has access to content
  useEffect(() => {
    const checkAccess = async () => {
      if (!user) {
        setHasAccess(false);
        setPaymentRequestStatus(null);
        return;
      }
      
      try {
        console.log("Checking access for user:", user.id, "content:", content.id);
        const { data: purchases, error } = await supabase
          .from('purchases')
          .select('*')
          .eq('content_id', content.id)
          .eq('user_id', user.id);
          
        if (error) throw error;
        
        const userHasAccess = Boolean(purchases && purchases.length > 0);
        console.log("Access check result:", userHasAccess, purchases);
        setHasAccess(userHasAccess);
        
        // Check payment request status
        const { data, error: requestError } = await supabase
          .from('payment_requests')
          .select('status')
          .eq('content_id', content.id)
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
          .limit(1);
          
        if (requestError) throw requestError;
        
        if (data && data.length > 0) {
          setPaymentRequestStatus(data[0].status);
        } else {
          setPaymentRequestStatus(null);
        }
      } catch (error) {
        console.error('Error checking access:', error);
        setHasAccess(false);
      }
    };
    
    checkAccess();
  }, [user, content.id]);

  const handleContentClick = () => {
    if (!user) {
      // Always direct to auth modal first if not logged in
      setIsAuthModalOpen(true);
    } else {
      // User is logged in, directly show content modal
      setIsModalOpen(true);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      let authResult;
      
      if (isLogin) {
        authResult = await supabase.auth.signInWithPassword({ email, password });
      } else {
        authResult = await supabase.auth.signUp({ email, password });
      }
      
      if (authResult.error) throw authResult.error;
      
      toast({
        title: isLogin ? "Login berhasil" : "Pendaftaran berhasil",
        description: isLogin ? "Anda telah masuk ke akun Anda" : "Silahkan cek email untuk verifikasi",
      });
      
      setIsAuthModalOpen(false);
      
      // Clear form
      setEmail('');
      setPassword('');
      
      // If login is successful, show the content modal after a short delay
      if (isLogin || authResult.data.session) {
        setTimeout(() => {
          setIsModalOpen(true);
        }, 500);
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handlePaymentRequest = async () => {
    if (!user) {
      setIsAuthModalOpen(true);
      return;
    }
    
    setIsPurchasing(true);
    try {
      // Create payment request
      const { data, error } = await supabase
        .from('payment_requests')
        .insert({
          content_id: content.id,
          user_id: user.id,
          amount: content.price,
          payment_method: 'transfer', // Default method
          status: 'pending'
        })
        .select();
        
      if (error) throw error;
      
      toast({
        title: "Permintaan pembayaran terkirim",
        description: "Admin akan memeriksa pembayaran Anda segera",
      });
      
      setPaymentRequestStatus('pending');
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsPurchasing(false);
      setShowTransferOptions(true);
    }
  };

  const handlePaymentSubmit = async () => {
    // In a real implementation, you would upload proof of payment and update the payment request
    toast({
      title: "Bukti pembayaran terkirim",
      description: "Admin akan memeriksa pembayaran Anda segera",
    });
    
    // Close modal after a short delay
    setTimeout(() => {
      setIsModalOpen(false);
      setShowTransferOptions(false);
    }, 1500);
  };

  const getPaymentUrls = () => {
    const savedUrls = localStorage.getItem('paymentUrls');
    if (savedUrls) {
      return JSON.parse(savedUrls);
    }
    
    // Default values
    return {
      ewallet: '',
      qris: ''
    };
  };

  return (
    <>
      <Card className="content-card cursor-pointer overflow-hidden transition-all duration-300 hover:shadow-lg hover:-translate-y-1" onClick={handleContentClick}>
        <div className="relative aspect-[4/3] overflow-hidden">
          {content.type === 'image' ? (
            <img 
              src={content.url} 
              alt={content.title} 
              className={`w-full h-full object-cover ${!hasAccess ? 'premium-blur' : ''}`} 
            />
          ) : (
            <div className="w-full h-full bg-gray-900 flex items-center justify-center">
              <span className={`text-white text-4xl ${!hasAccess ? 'premium-blur' : ''}`}>▶️</span>
            </div>
          )}
          <div className="absolute top-2 right-2 px-3 py-1 bg-gradient-to-r from-shinta-pink to-shinta-red text-white rounded-full text-sm font-semibold shadow-md">
            Rp {content.price.toLocaleString('id-ID')}
          </div>
        </div>
        <CardContent className="p-4 bg-white">
          <h3 className="font-semibold text-lg mb-1">{content.title}</h3>
          <p className="text-sm text-gray-500 line-clamp-2">{content.description}</p>
        </CardContent>
      </Card>

      {/* Auth Modal - Centered and Styled */}
      <Dialog open={isAuthModalOpen} onOpenChange={setIsAuthModalOpen}>
        <DialogContent className="sm:max-w-md mx-auto bg-white rounded-xl shadow-xl p-0 overflow-hidden">
          <DialogHeader className="bg-gradient-to-r from-shinta-pink to-shinta-red p-6">
            <DialogTitle className="text-center text-white text-2xl font-bold">
              {isLogin ? "Login untuk Melihat Konten" : "Daftar untuk Melihat Konten"}
            </DialogTitle>
          </DialogHeader>
          <div className="p-6">
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="mb-4">
                <label className="block text-sm font-medium mb-1 text-gray-700">
                  Email
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-shinta-pink"
                  required
                />
              </div>
              <div className="mb-6">
                <label className="block text-sm font-medium mb-1 text-gray-700">
                  Password
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-shinta-pink"
                  required
                />
              </div>
              <div className="flex flex-col gap-4">
                <Button
                  type="submit"
                  className="w-full py-2 bg-gradient-to-r from-shinta-pink to-shinta-red text-white rounded-md hover:opacity-90 transition-all"
                >
                  {isLogin ? "Login" : "Daftar"}
                </Button>
                <button
                  type="button"
                  className="text-center text-sm text-gray-600 hover:text-shinta-pink transition-colors"
                  onClick={() => setIsLogin(!isLogin)}
                >
                  {isLogin ? "Belum punya akun? Daftar" : "Sudah punya akun? Login"}
                </button>
              </div>
            </form>
          </div>
        </DialogContent>
      </Dialog>

      {/* Content Modal - Enhanced Design */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
          <div className="bg-white rounded-xl max-w-3xl w-full max-h-[90vh] overflow-auto shadow-2xl">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-bold bg-gradient-to-r from-shinta-pink to-shinta-red bg-clip-text text-transparent">{content.title}</h3>
                <button 
                  onClick={() => setIsModalOpen(false)} 
                  className="text-gray-500 hover:text-gray-700 w-8 h-8 rounded-full flex items-center justify-center hover:bg-gray-100 transition-colors"
                >
                  ✕
                </button>
              </div>
              
              <div className="mb-6">
                {content.type === 'image' ? (
                  <div className="relative rounded-xl overflow-hidden shadow-md">
                    <img 
                      src={content.url} 
                      alt={content.title} 
                      className={`w-full rounded-lg ${!hasAccess ? 'premium-blur' : ''}`} 
                    />
                    {!hasAccess && (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="bg-black/50 backdrop-blur-sm rounded-lg p-6 text-white text-center max-w-md">
                          <p className="font-bold text-2xl mb-2">Konten Premium</p>
                          <p>Lakukan pembayaran untuk melihat</p>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="relative aspect-video bg-gray-900 rounded-xl overflow-hidden shadow-md">
                    {hasAccess ? (
                      <video 
                        src={content.url} 
                        controls 
                        className="w-full h-full rounded-lg"
                      />
                    ) : (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="bg-black/50 backdrop-blur-sm rounded-lg p-6 text-white text-center">
                          <p className="font-bold text-2xl mb-2">Konten Premium</p>
                          <p className="premium-blur text-6xl mb-4">▶️</p>
                          <p>Lakukan pembayaran untuk melihat video</p>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
              
              <p className="mb-6 text-gray-700 leading-relaxed">{content.description}</p>
              
              {!hasAccess ? (
                <div className="border-t border-gray-100 pt-6">
                  <div className="text-center mb-6">
                    <p className="font-semibold text-xl mb-2">Konten Premium</p>
                    <p className="text-shinta-red font-bold text-3xl mb-4">Rp {content.price.toLocaleString('id-ID')}</p>
                    <p className="text-gray-500 mb-6">Akses konten ini dengan pembayaran sekali</p>
                    
                    {paymentRequestStatus === 'pending' && (
                      <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-xl mb-6">
                        <p className="font-medium text-yellow-800">Permintaan pembayaran sedang diproses</p>
                        <p className="text-sm text-yellow-700">Admin akan menyetujui akses Anda segera setelah pembayaran dikonfirmasi</p>
                      </div>
                    )}
                    
                    {paymentRequestStatus === 'rejected' && (
                      <div className="bg-red-50 border border-red-200 p-4 rounded-xl mb-6">
                        <p className="font-medium text-red-800">Pembayaran ditolak</p>
                        <p className="text-sm text-red-700">Silakan hubungi admin atau buat pembayaran baru</p>
                      </div>
                    )}
                    
                    {!paymentRequestStatus && (
                      !showTransferOptions ? (
                        <Button
                          onClick={handlePaymentRequest}
                          disabled={isPurchasing || paymentRequestStatus === 'pending'}
                          className="w-full py-6 rounded-xl font-medium text-lg bg-gradient-to-r from-shinta-pink to-shinta-red text-white hover:opacity-90 shadow-lg disabled:opacity-50 transition-all"
                        >
                          {isPurchasing ? "Memproses..." : "Bayar Sekarang"}
                        </Button>
                      ) : (
                        <div className="space-y-6">
                          <div className="p-6 border border-gray-200 rounded-xl bg-white shadow-md hover:shadow-lg transition-shadow">
                            <div className="flex items-center mb-4">
                              <IndianRupee className="text-shinta-pink mr-2" />
                              <h4 className="font-medium text-lg">Transfer E-wallet</h4>
                            </div>
                            <div className="text-left space-y-2 mb-4">
                              <p className="text-gray-700">Nama: <span className="font-medium">Shinta</span></p>
                              <p className="text-gray-700">Nomor: <span className="font-medium">081234567890</span></p>
                            </div>
                            <Button
                              onClick={handlePaymentSubmit}
                              className="w-full py-2 bg-shinta-pink text-white rounded-md hover:bg-shinta-red transition-colors"
                            >
                              Konfirmasi Pembayaran
                            </Button>
                          </div>
                          
                          <div className="p-6 border border-gray-200 rounded-xl bg-white shadow-md hover:shadow-lg transition-shadow">
                            <div className="flex items-center mb-4">
                              <QrCode className="text-shinta-pink mr-2" />
                              <h4 className="font-medium text-lg">QRIS</h4>
                            </div>
                            <div className="text-center mb-4">
                              <a 
                                href={getPaymentUrls().qris || '#'} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="block p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                              >
                                {getPaymentUrls().qris ? "Lihat QRIS" : "QRIS belum diatur"}
                              </a>
                            </div>
                            <Button
                              onClick={handlePaymentSubmit}
                              className="w-full py-2 bg-shinta-pink text-white rounded-md hover:bg-shinta-red transition-colors"
                            >
                              Konfirmasi Pembayaran
                            </Button>
                          </div>
                        </div>
                      )
                    )}
                  </div>
                </div>
              ) : (
                <div className="text-center p-4 bg-green-50 border border-green-200 rounded-xl">
                  <p className="text-green-700 font-bold text-lg">✓ Anda memiliki akses ke konten ini</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ContentCard;
