
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { User, LogOut } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

const Header = () => {
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { toast } = useToast();
  const navigate = useNavigate();
  const { user, isAdmin } = useAuth();
  
  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (email === 'sfajriaty410@gmail.com' && password === 'qwerty1') {
        // First sign in with Supabase
        const { data, error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        
        if (error) {
          // If the user doesn't exist yet, sign them up
          if (error.message.includes('Invalid login credentials')) {
            const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
              email,
              password,
            });
            
            if (signUpError) {
              throw signUpError;
            }
            
            // Check if the user was created successfully
            if (signUpData.user) {
              toast({
                title: "Admin account created",
                description: "Your admin account has been created successfully.",
              });
            }
          } else {
            throw error;
          }
        }
        
        // Set admin status in local storage
        localStorage.setItem('isAdmin', 'true');
        
        // Insert admin role into user_roles table if they don't exist
        if (data?.user) {
          const { error: roleError } = await supabase
            .from('user_roles')
            .upsert([
              {
                user_id: data.user.id,
                role: 'admin'
              }
            ]);
          
          if (roleError) {
            console.error('Error setting admin role:', roleError);
          }
        }
        
        toast({
          title: "Login successful",
          description: "Welcome back, admin!",
        });
        setShowAdminModal(false);
        navigate('/admin');
      } else {
        toast({
          title: "Login failed",
          description: "Invalid credentials",
          variant: "destructive",
        });
      }
    } catch (error: any) {
      console.error('Login error:', error);
      toast({
        title: "Login error",
        description: error.message || "An error occurred during login",
        variant: "destructive",
      });
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    toast({
      title: "Logout successful",
      description: "You have been logged out.",
    });
  };

  return (
    <header className="sticky top-0 z-50 w-full bg-white/90 backdrop-blur-md shadow-sm border-b border-shinta-softPink">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <h1 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-shinta-red to-shinta-pink bg-clip-text text-transparent">
            LOVABLE SHINTA 18+
          </h1>
        </Link>

        <div className="flex items-center gap-4">
          {user ? (
            <div className="flex items-center gap-3">
              <div className="hidden sm:flex items-center gap-2 px-3 py-1 rounded-full bg-gray-50 border border-gray-100">
                <User size={16} className="text-shinta-pink" />
                <span className="text-sm text-gray-700 font-medium">
                  {user.email?.split('@')[0]}
                </span>
              </div>
              
              <Button
                onClick={handleLogout}
                variant="ghost"
                className="text-sm text-gray-500 hover:text-shinta-red flex items-center gap-1"
                size="sm"
              >
                <LogOut size={16} />
                <span className="hidden sm:inline">Logout</span>
              </Button>
              
              {isAdmin && (
                <Link to="/admin">
                  <Button variant="outline" size="sm" className="border-shinta-pink text-shinta-pink hover:bg-shinta-softPink">
                    Admin
                  </Button>
                </Link>
              )}
            </div>
          ) : (
            <Button 
              variant="outline" 
              size="sm"
              className="border-shinta-pink text-shinta-pink hover:bg-shinta-softPink"
              onClick={() => {
                // Create a dummy content to trigger the auth modal
                const dummyContent = document.querySelector('.content-card');
                if (dummyContent) {
                  dummyContent.dispatchEvent(new Event('click'));
                }
              }}
            >
              Login
            </Button>
          )}
          
          <button 
            onClick={() => setShowAdminModal(true)}
            className="text-3xl hover:scale-110 transition-transform"
            aria-label="Admin Login"
          >
            🥰
          </button>
        </div>

        {/* Admin Login Modal */}
        <Dialog open={showAdminModal} onOpenChange={setShowAdminModal}>
          <DialogContent className="sm:max-w-md mx-auto bg-white rounded-xl shadow-xl p-0 overflow-hidden">
            <DialogHeader className="bg-gradient-to-r from-shinta-pink to-shinta-red p-6">
              <DialogTitle className="text-center text-white text-2xl font-bold">
                Admin Login
              </DialogTitle>
            </DialogHeader>
            <div className="p-6">
              <form onSubmit={handleAdminLogin} className="space-y-4">
                <div className="mb-4">
                  <label htmlFor="email" className="block text-sm font-medium mb-1 text-gray-700">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-shinta-pink"
                    required
                  />
                </div>
                <div className="mb-6">
                  <label htmlFor="password" className="block text-sm font-medium mb-1 text-gray-700">
                    Password
                  </label>
                  <input
                    type="password"
                    id="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-shinta-pink"
                    required
                  />
                </div>
                <div className="flex justify-end space-x-3">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowAdminModal(false)}
                    className="px-4 py-2 border rounded-md hover:bg-gray-50"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    className="px-4 py-2 bg-gradient-to-r from-shinta-pink to-shinta-red text-white rounded-md hover:opacity-90"
                  >
                    Login
                  </Button>
                </div>
              </form>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </header>
  );
};

export default Header;
