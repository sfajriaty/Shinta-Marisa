
import React, { createContext, useState, useEffect, useContext } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { User, Session } from '@supabase/supabase-js';
import { useToast } from '@/hooks/use-toast';

type AuthContextType = {
  user: User | null;
  session: Session | null;
  isLoading: boolean;
  isAdmin: boolean;
};

const AuthContext = createContext<AuthContextType>({
  user: null,
  session: null,
  isLoading: true,
  isAdmin: false,
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        console.log("Auth state changed:", event);
        setSession(session);
        setUser(session?.user ?? null);
        
        // Check admin status if user is logged in
        if (session?.user) {
          if (session.user.email === 'sfajriaty410@gmail.com') {
            setIsAdmin(true);
            console.log("Admin user detected");
          } else {
            setIsAdmin(false);
          }
          
          // Toast notification for login/logout
          if (event === 'SIGNED_IN') {
            toast({
              title: "Berhasil masuk",
              description: "Selamat datang kembali!",
              duration: 3000,
            });
          } else if (event === 'SIGNED_OUT') {
            toast({
              title: "Berhasil keluar",
              description: "Sampai jumpa kembali!",
              duration: 3000,
            });
          }
        }
        
        setIsLoading(false);
      }
    );

    // THEN check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      
      // Check admin status if user is logged in
      if (session?.user) {
        if (session.user.email === 'sfajriaty410@gmail.com') {
          setIsAdmin(true);
          console.log("Admin user detected on initial load");
        }
      }
      
      setIsLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  return (
    <AuthContext.Provider value={{ user, session, isLoading, isAdmin }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
